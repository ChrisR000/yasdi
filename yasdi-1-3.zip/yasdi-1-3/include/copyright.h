#ifndef __COPYRIGHT__H
#define __COPYRIGHT__H

#define SMA_COPYRIGHT_SHORT "2001-2010 SMA Solar Technology AG" 
#define SMA_COPYRIGHT "Copyright (c) " SMA_COPYRIGHT_SHORT 

#endif

