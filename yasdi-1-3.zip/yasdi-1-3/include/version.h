#ifndef __VERSION__H
#define __VERSION__H

//Version of the yasdi library 

//must be preprocessed with cmake!

#define LIB_YASDI_VER1 1
#define LIB_YASDI_VER2 8
#define LIB_YASDI_VER3 1
#define LIB_YASDI_VER4 9

#define LIB_YASDI_VERSION "1.8.1"
#define LIB_YASDI_VERSION_FULL "1.8.1Build9"

#endif
